# Douyin Downloader (Android)
Mở thư mục này bằng Android Studio → đợi Gradle sync → Build > Build APK(s).
- Nhận link qua menu Chia sẻ ("Tải Douyin"), ô Cài đặt nhanh, hoặc clipboard khi mở app.
- Tự lọc link từ đoạn text chia sẻ, lấy bản không watermark, bitrate/1080p cao nhất.
- Lưu vào Movies/Douyin.
