package com.dydl.app

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Nhận text từ menu Chia sẻ (hoặc từ ô Cài đặt nhanh -> đọc clipboard), tải rồi đóng ngay. */
class ShareActivity : AppCompatActivity() {
    private var handled = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        intent.getStringExtra(Intent.EXTRA_TEXT)?.let { handled = true; Downloader.start(this, it); finish() }
    }

    // Clipboard chỉ đọc được khi activity có focus (Android 10+)
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || handled) return
        handled = true
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        Downloader.start(this, text); finish()
    }
}
