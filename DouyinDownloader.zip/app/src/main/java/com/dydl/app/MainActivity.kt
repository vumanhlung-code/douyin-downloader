package com.dydl.app

import android.content.ClipboardManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var lastClip = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        input = EditText(this).apply { hint = "Dán đoạn chia sẻ Douyin vào đây"; minLines = 3 }
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }
        val btn = Button(this).apply { text = "TẢI VIDEO (chất lượng cao nhất)"
            setOnClickListener { Downloader.start(this@MainActivity, input.text.toString()) { status.text = it } } }
        val help = TextView(this).apply { setPadding(0, pad, 0, 0); text =
            "Cách dùng nhanh:\n" +
            "• Douyin → Chia sẻ → chọn \"Tải Douyin\" (trong mục Khác/More): tải ngay.\n" +
            "• Douyin → Chia sẻ → WeChat (link được copy) → kéo thanh thông báo, chạm ô \"Tải Douyin\".\n" +
            "• Hoặc mở app này: tự nhận link trong clipboard và tải.\n" +
            "Video lưu ở Movies/Douyin." }
        setContentView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.TOP; setPadding(pad, pad, pad, pad)
            addView(input); addView(btn); addView(status); addView(help) }) })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (t != lastClip && DouyinParser.extractUrl(t) != null) {
            lastClip = t; input.setText(t)
            Downloader.start(this, t) { status.text = it }
        }
    }
}
