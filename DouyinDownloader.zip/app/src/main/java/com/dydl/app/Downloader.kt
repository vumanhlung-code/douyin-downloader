package com.dydl.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.*

object Downloader {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())

    fun start(ctx: Context, text: String, onDone: (String) -> Unit = {}) {
        val app = ctx.applicationContext
        if (DouyinParser.extractUrl(text) == null) { toast(app, "Không có link Douyin"); onDone("Không có link"); return }
        toast(app, "Đang lấy link video…")
        scope.launch {
            val msg = try {
                val v = DouyinParser.parse(text)
                val name = v.title.replace(Regex("""[\\/:*?"<>|#\n\r]"""), " ").trim().take(60).ifEmpty { v.id }
                val req = DownloadManager.Request(Uri.parse(v.url))
                    .addRequestHeader("User-Agent", DouyinParser.UA)
                    .addRequestHeader("Referer", "https://www.douyin.com/")
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "Douyin/${name}_${v.id}.mp4")
                (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                "Đang tải: $name → Movies/Douyin"
            } catch (e: Exception) { "Lỗi: ${e.message}" }
            toast(app, msg); main.post { onDone(msg) }
        }
    }

    private fun toast(c: Context, s: String) = main.post { Toast.makeText(c, s, Toast.LENGTH_LONG).show() }
}
