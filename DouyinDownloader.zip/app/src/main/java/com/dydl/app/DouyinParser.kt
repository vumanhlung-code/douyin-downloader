package com.dydl.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

object DouyinParser {
    const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
    private val client = OkHttpClient.Builder().followRedirects(true).build()

    data class Video(val id: String, val url: String, val title: String)

    /** Lọc link từ đoạn text chia sẻ kiểu "0- 长按复制... https://v.douyin.com/xxx/ 4@2.com :5pm" */
    fun extractUrl(text: String): String? =
        Regex("""https?://(v\.douyin\.com|www\.douyin\.com|www\.iesdouyin\.com|m\.douyin\.com)/[A-Za-z0-9_\-/?=&%.]+""")
            .find(text)?.value

    private fun get(url: String): Pair<String, String> {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        client.newCall(req).execute().use { r -> return r.request.url.toString() to (r.body?.string() ?: "") }
    }

    fun parse(shareText: String): Video {
        val link = extractUrl(shareText) ?: error("Không tìm thấy link Douyin")
        val (finalUrl, _) = get(link)
        val id = Regex("""(?:video|note)/(\d+)""").find(finalUrl)?.groupValues?.get(1)
            ?: Regex("""modal_id=(\d+)""").find(finalUrl)?.groupValues?.get(1)
            ?: Regex("""(\d{15,})""").find(finalUrl)?.groupValues?.get(1)
            ?: error("Không lấy được ID video")

        val (_, html) = get("https://www.iesdouyin.com/share/video/$id/")
        val json = Regex("""window\._ROUTER_DATA\s*=\s*(\{.*?\})</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1) ?: error("Không đọc được dữ liệu trang (Douyin có thể đã đổi cấu trúc)")
        val loader = JSONObject(json).getJSONObject("loaderData")
        val pageKey = loader.keys().asSequence().first { it.contains("page") }
        val item = loader.getJSONObject(pageKey).getJSONObject("videoInfoRes")
            .getJSONArray("item_list").getJSONObject(0)
        val title = item.optString("desc", id)
        val video = item.getJSONObject("video")

        // 1) Ưu tiên bit_rate có bitrate cao nhất (nếu có)
        var best: String? = null
        video.optJSONArray("bit_rate")?.let { arr ->
            var max = -1
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val br = o.optInt("bit_rate")
                val u = o.optJSONObject("play_addr")?.optJSONArray("url_list")?.optString(0)
                if (br > max && !u.isNullOrEmpty()) { max = br; best = u }
            }
        }
        // 2) Mặc định: dùng uri, ép 1080p, bỏ watermark (playwm -> play)
        if (best == null) {
            val uri = video.getJSONObject("play_addr").getString("uri")
            best = if (uri.startsWith("http")) uri
                   else "https://aweme.snssdk.com/aweme/v1/play/?video_id=$uri&ratio=1080p&line=0"
        }
        val url = best!!.replace("playwm", "play").replace("ratio=720p", "ratio=1080p")
        return Video(id, url, title)
    }
}
