package com.dydl.app

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

object DouyinParser {
    const val UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

    data class Video(val id: String, val url: String, val title: String)

    /** Lọc link từ đoạn text chia sẻ kiểu "0- 长按复制... https://v.douyin.com/xxx/ 4@2.com :5pm" */
    fun extractUrl(text: String): String? =
        Regex("""https?://(v\.douyin\.com|www\.douyin\.com|www\.iesdouyin\.com|m\.douyin\.com)/[A-Za-z0-9_\-/?=&%.]+""")
            .find(text)?.value

    /** Mở link trong WebView ẩn (như trình duyệt thật) để vượt chặn, rồi lấy dữ liệu video. */
    suspend fun parse(ctx: Context, shareText: String): Video {
        val link = extractUrl(shareText) ?: error("Không tìm thấy link Douyin")
        return withTimeout(30_000) { loadInWebView(ctx.applicationContext, link) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun loadInWebView(ctx: Context, link: String): Video =
        suspendCancellableCoroutine { cont ->
            val main = Handler(Looper.getMainLooper())
            main.post {
                val wv = WebView(ctx)
                var done = false
                var sniffed: String? = null   // link video bắt được từ request mạng
                var id = ""
                fun finish(v: Video?, err: String? = null) {
                    if (done) return; done = true
                    main.post { wv.stopLoading(); wv.destroy() }
                    if (v != null) cont.resume(v) else cont.resumeWith(Result.failure(Exception(err)))
                }
                cont.invokeOnCancellation { main.post { if (!done) { done = true; wv.destroy() } } }

                CookieManager.getInstance().setAcceptCookie(true)
                wv.settings.apply {
                    javaScriptEnabled = true; domStorageEnabled = true
                    userAgentString = UA; mediaPlaybackRequiresUserGesture = true
                    blockNetworkImage = true
                }
                var tries = 0
                fun probe() {
                    if (done) return
                    wv.evaluateJavascript(
                        "(function(){try{return JSON.stringify(window._ROUTER_DATA||null)}catch(e){return null}})()"
                    ) { raw ->
                        if (done) return@evaluateJavascript
                        val json = try { JSONArray("[$raw]").optString(0, "") } catch (e: Exception) { "" }
                        val v = if (json.isNotEmpty() && json != "null") runCatching { fromRouter(json) }.getOrNull() else null
                        when {
                            v != null -> finish(v)
                            sniffed != null -> finish(Video(id.ifEmpty { "video" }, sniffed!!, id.ifEmpty { "douyin" }))
                            ++tries < 15 -> main.postDelayed({ probe() }, 1000)
                            else -> finish(null, "Không lấy được video (có thể là ảnh, video riêng tư hoặc đã xoá)")
                        }
                    }
                }
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                        val u = req.url.toString()
                        if (sniffed == null && (u.contains("douyinvod.com") || u.contains("/aweme/v1/play"))) sniffed = u.replace("playwm", "play")
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        Regex("""(?:video|note)/(\d+)""").find(url)?.let { id = it.groupValues[1] }
                        // Trang douyin.com bản PC -> chuyển sang trang chia sẻ mobile dễ đọc hơn
                        if (id.isNotEmpty() && !url.contains("iesdouyin.com/share")) {
                            view.loadUrl("https://www.iesdouyin.com/share/video/$id/"); return
                        }
                        main.postDelayed({ probe() }, 800)
                    }
                }
                wv.loadUrl(link)
            }
        }

    /** Đọc JSON window._ROUTER_DATA, chọn luồng chất lượng cao nhất, bỏ watermark. */
    private fun fromRouter(json: String): Video {
        val loader = JSONObject(json).getJSONObject("loaderData")
        val pageKey = loader.keys().asSequence().first { loader.optJSONObject(it)?.has("videoInfoRes") == true }
        val item = loader.getJSONObject(pageKey).getJSONObject("videoInfoRes")
            .getJSONArray("item_list").getJSONObject(0)
        val id = item.optString("aweme_id", "video")
        val title = item.optString("desc", id)
        val video = item.getJSONObject("video")

        var best: String? = null
        video.optJSONArray("bit_rate")?.let { arr ->
            var max = -1
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val br = o.optInt("bit_rate")
                val u = o.optJSONObject("play_addr")?.optJSONArray("url_list")?.optString(0)
                if (br > max && !u.isNullOrEmpty()) { max = br; best = u }
            }
        }
        if (best == null) {
            val uri = video.getJSONObject("play_addr").getString("uri")
            best = if (uri.startsWith("http")) uri
                   else "https://aweme.snssdk.com/aweme/v1/play/?video_id=$uri&ratio=1080p&line=0"
        }
        val url = best!!.replace("playwm", "play").replace("ratio=720p", "ratio=1080p")
        return Video(id, url, title)
    }
}
